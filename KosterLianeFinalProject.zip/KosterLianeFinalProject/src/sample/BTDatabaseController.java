/* Liane Koster
    ISYS 316 Section 1
    Instructor: Hira Herrington
    Assignment 7 - Final Project
    Due Date: 5/3/21

    Liane Koster, 5/3/21
    The purpose of this assignment is to improve upon Assignment 4 of a bank teller ATM program by implementing and
        connecting to a MySQL database to provide and handle all account authentications and transactions; this project
        also includes a Scenebuilder GUI to display an ATM interface for user authentication and buttons for a user's
        balance, deposit, and withdraw functions
    Inputs include: Using Scenebuilder as a whole (the GUI itself), TextArea textResult, method initialize where Java
        connects to the MySQL database, String inputNumber to fetch the account from the database, and the JOptionPanes
        in the deposit and withdraw methods to get the user input
    Outputs include: the Main/start where the program can launch and TextArea textResult (the setText to display the
        amounts/balance back to the user)
    Interfaces include: the Scenebuilder GUI, public void textResultOA, public void numKeypad, public void cancelButton,
        public void buttonBalance, public void buttonDeposit, public void buttonWithdraw, and public void ButtonEnter;
        also includes every ResultSet and PreparedStatement called within each method
    Variables include: textResult, the statement and connection called to help connect to the database, String
        inputNumber, double balance, double depositAmount, and double withdrawAmount
 */

package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;

import javax.swing.*;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class BTDatabaseController implements Initializable {
    //variables - text area from scenebuilder
    @FXML
    private TextArea textResult;

    //database variables for connections
    private Connection connection;
    private Statement statement;

    //start initialize - database connection
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        //try-catch block to establish connection to database
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.print("Driver loaded\n");

            // Establish a connection
            // Create instance of connection and statement objects
            connection = DriverManager.getConnection("jdbc:mysql://localhost/javabook", "scott", "tiger");
            System.out.println("Database connected");

            // Create statement
            statement = connection.createStatement();

            //processing resultset - get data from database checkingaccount
            ResultSet resultSet = statement.executeQuery("select * from checkingaccount");

        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
    }

    //to get text field inputs and outputs
    public void textResultOA(ActionEvent txt) { textResult.setText(textResult.getText()); }

    //allows keypad to work based on pressed number
    public void numKeypad(ActionEvent NKP) {
        String Nums = ((Button) NKP.getSource()).getText();
        textResult.setText(textResult.getText() + Nums);
    }

    //cancel button
    public void cancelButton(ActionEvent cancelBPressed) {
        textResult.clear();
    }

    //button methods
    //BALANCE BUTTON - WORKS WHEN YOU ENTER ACCOUNT NUMBER THEN IMMEDIATELY PRESS BALANCE BUTTON
    public void buttonBalance(ActionEvent actionEvent) throws SQLException {
        String inputNumber = textResult.getText();

        statement = connection.createStatement();
        ResultSet resultB = statement.executeQuery("SELECT balance FROM checkingaccount WHERE accountNo " +
                " = '" + inputNumber + "'");

        //display balance back to user
        if (resultB.next()) {
            String balance = resultB.getString("Balance");
            textResult.setText("Your account balance is: $" + balance);
        } else {
            textResult.setText("ERROR: BALANCE DETAILS");
        }
    }

    //DEPOSIT BUTTON - WORKS WHEN YOU ENTER ACCOUNT NUMBER THEN IMMEDIATELY PRESS DEPOSIT BUTTON
    public void buttonDeposit(ActionEvent actionEvent) throws SQLException {
        String inputNumber = textResult.getText();
        double balance = Double.parseDouble(textResult.getText());
        double depositAmount = Double.parseDouble(textResult.getText());

        //getting balance
        statement = connection.createStatement();
        ResultSet resultD = statement.executeQuery("SELECT balance FROM checkingaccount WHERE accountNo = '"
                + inputNumber + "';");
        while (resultD.next()) {
            String tmpString = resultD.getString("Balance");
            balance = Double.parseDouble(tmpString);

            //display separate screen for user to enter in deposit amount
            String DA = JOptionPane.showInputDialog(null, "Enter amount to deposit: ");
            depositAmount = Double.parseDouble(DA);
        }

        //update balance
        PreparedStatement preparedStatement = connection.prepareStatement("UPDATE checkingaccount set balance = '"
                + (balance + depositAmount) + "' WHERE accountNo = '" + inputNumber + "';");
        preparedStatement.executeUpdate();

        // Find new balance from the after deposited
        resultD = statement.executeQuery("SELECT balance FROM checkingaccount WHERE accountNo = '"
                + inputNumber + "';");

        //print output of new balance to user
        while (resultD.next()) {
            String number = resultD.getString("Balance");
            balance = Double.parseDouble(number);
            if (depositAmount > 0) {
                textResult.setText("Your new balance is: $" + balance);
            } else {
                textResult.setText("ERROR: Deposit method.");
            }
        }
    }

    //WITHDRAW BUTTON - WORKS WHEN YOU ENTER ACCOUNT NUMBER THEN IMMEDIATELY PRESS WITHDRAW BUTTON
    public void buttonWithdraw(ActionEvent actionEvent) throws SQLException {
        String inputNumber = textResult.getText();
        double balance = Double.parseDouble(textResult.getText());
        double withdrawAmount = Double.parseDouble(textResult.getText());

        //getting balance
        ResultSet resultW = statement.executeQuery("select balance from CheckingAccount where accountNo = '"
                + inputNumber + "';");
        while (resultW.next()) {
            String number = resultW.getString("Balance");
            balance = Double.parseDouble(number);

            //display separate screen for user to enter in withdraw amount
            String WA = JOptionPane.showInputDialog(null, "Enter amount to withdraw: ");
            withdrawAmount = Double.parseDouble(WA);
        }

        //withdraw has to be in range of user balance and greater than 0
        if (withdrawAmount > balance || withdrawAmount <= 0) {
            textResult.setText("Enter new withdraw amount!");
        } else {
            //update commands for account and transaction
            PreparedStatement preparedSt = connection.prepareStatement("update CheckingAccount set balance = '"
                    + (balance - withdrawAmount) + "' where accountNo = '" + inputNumber + "';");
            preparedSt.executeUpdate();
        }

        // Get the new balance
        resultW = statement.executeQuery("select balance from CheckingAccount where accountNo = '" +
                inputNumber + "';");
        while (resultW.next()) {
            String number = resultW.getString("Balance");
            balance = Double.parseDouble(number);

            //print new balance to user
            if (withdrawAmount > 0 || withdrawAmount < balance) {
                textResult.setText("Your new balance is: $" + balance);
            } else {
                textResult.setText("ERROR: Withdraw method.");
            }
        }
    } //end withdraw

    //ENTER BUTTON - for entering user account
    public void buttonEnter(ActionEvent actionEvent) throws SQLException {
        String inputNumber = textResult.getText();

        // sql to find the account
        statement = connection.createStatement();

        String SQL = "Select accountNo FROM checkingaccount WHERE accountNo = '" + inputNumber + "'";

        this.textResult.clear();
        ResultSet resultCheck = statement.executeQuery(SQL);

        //prints result of active account to user
        while (resultCheck.next()) {
            String inputNumber1 = resultCheck.getString(1);
            if (inputNumber.equals(inputNumber1)) {
                textResult.setText("Welcome Account #: " + resultCheck.getString(1)
                        + "\nSelect next transaction -->");
            } else {
                textResult.setText("Enter valid account details.");
            }
        }
    } //end enter
} //end BTController
