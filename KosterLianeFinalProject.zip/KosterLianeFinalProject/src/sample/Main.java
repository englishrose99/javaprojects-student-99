package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Main extends Application {

    //main/start used to launch scenebuilder app
    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("BTDatabase.fxml"));
        primaryStage.setTitle("BankTellerDatabase");
        primaryStage.setScene(new Scene(root, 400, 420));
        primaryStage.show();
    }
}
